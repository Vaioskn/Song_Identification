Στο παρακάτω λινκ:

https://drive.google.com/drive/folders/14lFqCtpX107GSo5Rm1N7svEtqegi4nbx?usp=sharing

Έχουμε όλα τα μοντέλα (βάρη, label maps), τα datasets, τα αποτελέσματα (plots, csv files) και τον κώδικα, όλα οργανωμένα, εάν θέλετε να τα δείτε αναλυτικά (8GB σύνολο)

- Βάιος και Αποστόλης